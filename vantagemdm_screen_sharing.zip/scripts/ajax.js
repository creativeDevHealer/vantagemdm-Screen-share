// Ajax calls.

var ajax = {
  loadSettings: async function (type) {
    let settings = await storage.get("__settings");
    helpers.customConsoleLog(
      "ajax.js",
      ["loadSettings", "settings", settings],
      false
    );

    if (settings !== null) {
      var settingsData = settings;
      settings = {};
      if (helpers.isValidJson(settingsData)) {
        helpers.customConsoleLog(
          "ajax.js",
          ["loadSettings", settingsData],
          false
        );

        settings = settingsData;
      }
      helpers.customConsoleLog("ajax.js", ["loadSettings", settings], false);
    } else {
      settings = {
        currentScreenCastingMode: "disabled",
        screenRecording: [],
      };
      await storage.set("__settings", settings);
      helpers.customConsoleLog(
        "ajax.js",
        [
          "loadSettings",
          "settings not found and set storage called.",
          settings,
        ],
        false
      );

      type = true;
    }

    let commandUuids = [];
    let mappingId = await storage.get("mappingId");
    let deviceKey = await storage.get("deviceKey");
    //var mappingId = storage.get("mappingId");
    if (mappingId == null) {
      // console.log("ajax", "mappingId", mappingId);
      helpers.customConsoleLog(
        "ajax.js",
        ["loadSettings", "mappingId", mappingId],
        false
      );
      return commandUuids;
    }

    var url =
      getSettingsUrl +
      "?agent=" +
      agent +
      "&mappingId=" +
      mappingId +
      "&deviceUdid=" +
      deviceKey;
    //if (type) url = url + "&includeDefaultSettings=yes";
    saveLogsIntoCache(
      time.getCurrentDateTime(true) +
        " - url to get settings for mdm server: " +
        url +
        " \r\n"
    );
    helpers.customConsoleLog(
      "ajax.js",
      ["loadSettings", "settingsUrl", url],
      false
    );

    await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      async: false,
    })
      .then((response) => response.json())
      .then((res) => {
        saveLogsIntoCache(
          time.getCurrentDateTime(true) +
            " - settings response: " +
            JSON.stringify(res) +
            " \r\n"
        );

        if (typeof res === "string") {
          res = JSON.parse(res);
        }

        if (res.code === 200) {
          for (let i = 0; i < res.settings.length; i++) {
            if (res.settings[i].name === "ScreenRecording") {
              commandUuids.push(res.settings[i].uuid);

              if (Object.keys(res.settings[i].data).length === 0) {
                helpers.customConsoleLog(
                  "ajax.js",
                  ["loadSettings", "setting is disabled"],
                  true
                );
              } else {
                helpers.customConsoleLog(
                  "ajax.js",
                  ["loadSettings", "screenshot enabled section"],
                  true
                );

                settings.currentScreenCastingMode = "enabled";

                settings.screenRecording = res.settings[i].data;
              }
            }
          }
        }
      })
      .catch((error) => {
        saveLogsIntoCache(
          time.getCurrentDateTime(true) +
            " - exception while get settings: " +
            JSON.stringify(error) +
            " \r\n"
        );
      });

    settings.commands = commandUuids;
    await storage.set("__settings", settings);
    //console.log("loadSettingsConsole", settings);
    if (settings.screenRecording?.action === "start") {
      let CurrentCommandStatus = await storage.get("CurrentCommandStatus");
      if (CurrentCommandStatus !== "progress") {
        await storage.set("CurrentCommandStatus", "");
      }
    } else if (settings.screenRecording?.action === "stop") {
      await storage.set("CurrentCommandStatus", "");
    }

    helpers.customConsoleLog(
      "ajax.js",
      [
        "loadSettings",
        "commandUuids : " + JSON.stringify(commandUuids),
        "settings : " + JSON.stringify(settings),
      ],
      true
    );
    return commandUuids;
  },

  callBackToServer: async function (commandUuid) {
    let mappingId = await storage.get("mappingId");
    let deviceKey = await storage.get("deviceKey");
    let data =
      '{"commandUuids":["' +
      commandUuid +
      '"],"commandDetails":[{"uuid":"' +
      commandUuid +
      '","error":"SUCCESS","errorDescription":""}]}';
    saveLogsIntoCache(
      time.getCurrentDateTime(true) +
        " - sending callback to server against commandUUid: " +
        commandUuid +
        " \r\n"
    );

    let url =
      getCallBackUrl + "&deviceUdid=" + deviceKey + "&mappingId=" + mappingId;
    helpers.customConsoleLog("ajax.js", ["callBackToServer", url], false);

    let formData = data;
    let myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var requestOptions = {
      method: "PUT",
      headers: myHeaders,
      body: formData,
    };
    helpers.customConsoleLog(
      "ajax.js",
      ["callBackToServer", url, requestOptions],
      true
    );

    await fetch(url, requestOptions)
      .then((response) => response.json())
      .then((res) => {
        // Handle the success case
      })
      .catch((error) => {
        saveLogsIntoCache(
          time.getCurrentDateTime(true) +
            " - exception while send callback: " +
            JSON.stringify(error) +
            " \r\n"
        );
      });
  },
};
