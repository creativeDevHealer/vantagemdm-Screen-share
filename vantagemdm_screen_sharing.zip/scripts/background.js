importScripts("common.js");

let flatennedBookmarks = [];
let screenRecording = [];
let url = "";
let tabId = "";
let mappingId = "";
let mappingData = "";
let bookmarks = [];

let mappingDataJson = "";

let settingsData = "";
let settings = "";
let currentScreenCastingModeObj = "";
let currentScreenCastingMode = "";

let contentScript = "";

let contentScriptPort = null;

chrome.runtime.onInstalled.addListener(async function (details) {
  currentScreenCastingModeObj = await chrome.storage.local.get(
    "currentScreenCastingMode"
  );

  await storage.set("CurrentCommandStatus", "");
  currentScreenCastingMode =
    currentScreenCastingModeObj.currentScreenCastingMode;
  helpers.customConsoleLog("background.js", "onInstalled.addListener", true);

  if (details.reason == "install" || details.reason == "update") {
    if (currentScreenCastingMode === true) {
    } else {
      chrome.tabs.create({ url: "/views/page.html" });
    }
  }
  var logsStr =
    time.getCurrentDateTime(true) +
    " - " +
    details.reason +
    " chrome extension " +
    JSON.stringify(details) +
    ".\r\n";
  saveLogsIntoCache(logsStr);
});

chrome.runtime.setUninstallURL(
  "https://www.vantagemdm.com/?mappingId=" + deviceKey
);

try {
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    url = tab.url;
    tabId = tabId;
    currentScreenCastingMode = await storage.get("currentScreenCastingMode");
    mappingData = await storage.get("mappingData");

    mappingId = await storage.get("mappingId");

    helpers.customConsoleLog("background.js", ["onUpdated.addListener"], true);

    if (helpers.isValidJson(mappingData)) {
      mappingDataJson = JSON.parse(mappingData);
    }

    if (changeInfo.status == "complete" && tab.active) {
      /* helpers.customConsoleLog(
        "background.js",
        ["onUpdated", tabId, changeInfo, tab],
        false
      );*/
      // chrome.tabs.sendMessage(tabId, JSON.stringify({ action: "start" }));
      /* helpers.customConsoleLog(
        "background.js",
        ["onUpdated", { action: "start" }],
        false
      );*/
    }
  });
} catch (e) {
  helpers.customConsoleLog("background.js", ["error", e], true);
}

/*
 * Recieve incoming messages.
 */
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "get-bookmarks") {
    chrome.bookmarks.getTree(function (tree) {
      if (flatennedBookmarks.length === 0) flattenBookmarks(tree);
    });
    helpers.customConsoleLog(
      "background.js",
      ["get-bookmarks", flatennedBookmarks],
      false
    );
    sendResponse({ bookmarks: flatennedBookmarks });
  } else if (request.method == "sign_up") {
    sendResponse({ code: "100" });
  } else if (request.method == "load_settings") {
    saveLogsIntoCache(
      time.getCurrentDateTime(true) + " - loading settings for first time \r\n"
    );

    this.loadSettings(true);
    uploadDebugLogs();
  } else {
    setTimeout(() => {
      sendResponse({ response: "async response from background script" });
    }, 1000);
  }
});

async function sendCommandtoBackground() {
  currentScreenCastingMode = await storage.get("currentScreenCastingMode");
  settingsData = await storage.get("__settings");

  helpers.customConsoleLog(
    "loadSettings",
    ["background.js", "settingsData", settingsData],
    false
  );

  if (helpers.isValidJson(settingsData)) {
    settings = settingsData;

    helpers.customConsoleLog("background.js", ["settings", settings], false);
  }

  if (typeof settings.screenRecording !== "undefined") {
    screenRecording = settings.screenRecording;
    helpers.customConsoleLog(
      "classDone",
      ["screenRecording", screenRecording],
      false
    );

    if (
      currentScreenCastingMode != "disabled" &&
      typeof screenRecording.action !== "undefined"
    ) {
      helpers.customConsoleLog(
        "background.js",
        ["screenRecording", screenRecording],
        false
      );
      // send command to content.js
      let data = { action: screenRecording.action };
      helpers.customConsoleLog(
        "background.js",
        ["screenRecording", data],
        false
      );

      // await contentPort.postMessage(data);
    } else {
      helpers.customConsoleLog(
        "background.js",
        "screenRecording mode is disabled"
      );
    }
  } else {
    helpers.customConsoleLog(
      "background.js",
      "settings.screenRecording not found",
      false
    );
  }
}

/*
 *Function to load settings from ajax file
 */
async function loadSettings(type) {
  let commandUuids = await ajax.loadSettings(type);

  for (i = 0; i < commandUuids.length; i++) {
    ajax.callBackToServer(commandUuids[i]);
  }

  // await sendCommandtoBackground();
  //return true;
}

/*
 *Function to get bookmarks
 */
function flattenBookmarks(bookmarks) {
  for (let i = 0; i < bookmarks.length; i++) {
    const bookmark = bookmarks[i];
    if (bookmark.url) {
      flatennedBookmarks.push({
        title: bookmark.title.toLowerCase(),
        orignalTitle: bookmark.title,
        url: bookmark.url,
      });
    }
    if (bookmark.children) {
      flattenBookmarks(bookmark.children);
    }
  }
}
/*
 * load new settings from server every 2 minutes.
 */
loadSettingsInterval = 1 * 60000;
loadInterval = setInterval(async function () {
  this.loadSettings(false);

  await storage.set("lastSettingCheck", time.accessTime(false));
}, loadSettingsInterval);
/*
 * upload debug log file while its size of 50KB.
 */
uploadDebugLogFileInterval = 5 * 60000;

debugLogFileInterval = setInterval(async function () {
  var extensionLogs = await storage.get("extensionLogs");
  //var extensionLogs = localStorage.getItem('extensionLogs');
  if (typeof extensionLogs !== "undefined") {
    var FileSize = extensionLogs.length / 1024; //in KB
    if (FileSize > 50) {
      saveLogsIntoCache(
        time.getCurrentDateTime(true) +
          " - debugLogs size is reached to 50 KB now uploading debugLog file \r\n"
      );
      uploadDebugLogs();
    }
  }
}, uploadDebugLogFileInterval);

/*
 * check for chrome book registrations after every 1 minute
 */
loadConnectInterval = 1 * 60000;
connectInterval = setInterval(async function () {
  let serialNumber = await storage.get("serialNumber");

  //let vantageMDMConnect = storage.get('VantageMDMScreenCastingConnect');
  currentScreenCastingMode = await storage.get("currentScreenCastingMode");

  if (
    (currentScreenCastingMode == null || currentScreenCastingMode == "false") &&
    serialNumber != null &&
    serialNumber != ""
  ) {
    var jsonData = "";
    var jsonObject = {
      userName: "",
      password: serialNumber,
      resellerId: "VantageMDM",
      deviceKey: deviceKey,
      platform: platform,
      productVersion: buildVersion,
      productName: resellerId,
      timeZoneOffset: 0,
      udid: deviceKey,
      ChromeVersion: ChromeVersion,
      serial: ChromeVersion,
      enrollmentMode: "GOOGLE_CHROME_BOOK",
    };
    var formData = JSON.stringify(jsonObject);
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    var urlencoded = new URLSearchParams();
    urlencoded.append("formData", formData);
    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: urlencoded,
      redirect: "follow",
    };

    helpers.customConsoleLog(
      "background.js",
      ["subcribeUrl", subcribeUrl, requestOptions],
      false
    );
    fetch(subcribeUrl, requestOptions)
      .then(function (response) {
        helpers.customConsoleLog(
          "background.js",
          ["response", response],
          false
        );
        if (!response.ok) {
          throw new Error("Something went wrong, Please try again.");
        }
        return response.json();
      })
      .then(async function (html) {
        saveLogsIntoCache(
          getCurrentDateTime(true) +
            " - response from server " +
            JSON.stringify(html) +
            ".\r\n"
        );
        var obj = html;
        try {
          if (obj.code == 100) {
            jsonData = {
              mappingId: obj.mappingId,
              code: obj.code,
              screenCastingURL: obj.screenCastingURL,
              rtmpUrl: obj.rtmpUrl,
              deviceId: obj.deviceId,
              mdmUrl: obj.mdmUrl,
              deviceName: $("#email").val(),
              deviceKey: obj.deviceKey,
              productVersion: buildVersion,
              protocol: obj.protocol,
              port: obj.port,
              host: obj.host,
              streamMode: obj.streamMode,
              companyUrl: obj.companyUrl,
              companyName: obj.companyName,
            };
            await storage.set("mappingData", JSON.stringify(jsonData));
            await storage.set("mappingId", obj.mappingId);
            await storage.set("deviceKey", obj.deviceKey);
            await storage.set("currentScreenCastingMode", true);

            uploadDebugLogs();
          } else if (obj.code == 301) {
            await storage.set("serialNumber", serialNumber);
            await storage.set("currentScreenCastingMode", false);
          } else if (obj.code == 414 || obj.code == 430) {
            await storage.set("serialNumber", serialNumber);
            await storage.set("currentScreenCastingMode", false);
          } else {
            await storage.set("mappingData", false);
            await storage.set("currentScreenCastingMode", false);
          }
        } catch (ex) {
          await storage.set("mappingData", false);
          await storage.set("currentScreenCastingMode", false);
        }
      })
      .catch(async function (error) {
        helpers.customConsoleLog("background.js", ["error", e], true);
        await storage.set("mappingData", false);
        await storage.set("currentScreenCastingMode", false);
      });
  }
}, loadConnectInterval);

// background-script.js

function handleMessage(request, sender, sendResponse) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ response: "async response from background script" });
    }, 1000);
  });
}
chrome.runtime.onMessage.addListener(handleMessage);
