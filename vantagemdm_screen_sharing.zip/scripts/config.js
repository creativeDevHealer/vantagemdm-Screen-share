var overLayDivHtml =
  '<div class="widget-box-overlay"><i class=" ace-icon loading-icon fa fa-spinner fa-spin fa-2x white"></i></div>';
var overLayErrorDivHtml =
  '<div class="alert alert-danger"><button data-dismiss="alert" class="close" type="button"><i class="ace-icon fa fa-times"></i></button><strong><i class="ace-icon fa fa-times"></i> Connection Timeout! </strong> Please try again.</div>';
var emailRegex =
  /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
var platform = "chrome";
var buildVersion = "CHROME-R-1.0.6";
var ChromeVersion = (/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
var resellerId = "VantageMDM";
var searchTerm = "VantageMDM-Enrollment";
var deviceKey = chrome.runtime.id;
var timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
//var userId = "";
var agent = "screenSharing";
var browser = "Chrome";
const { userAgent } = navigator;
//console.log("userAgent", userAgent);

if (userAgent.includes("Chromium")) {
  browser = "Chromium";
} else if (userAgent.includes("Firefox/")) {
  browser = "Firefox";
} else if (userAgent.includes("Edg/")) {
  browser = "Edge";
} else if (userAgent.includes("Chrome/")) {
  browser = "Chrome";
} else if (userAgent.includes("Safari/")) {
  browser = "Safari";
}

/*** LIVE SERVER CREDENTIALS ****/
//var serverURL = "https://live-server.vantagemdm.com";
//var mdmServerURL = "https://live-mdm.vantagemdm.com:8553/mdm";
//var phpUrl = "cp.vantagemdm.com";

/*** LIVE STAGING SERVER CREDENTIALS ***/
var serverURL = "https://ns-server.vantagemdm.com";
var mdmServerURL = "https://ns-mdm.vantagemdm.com:8553/mdm";
var phpUrl = "ns-cp.vantagemdm.com";

/*** WEB SERVICES ****/
var socketUrl = "https://p2p.vantagemdm.com:8890";
var signUpUrl = serverURL + "/secure/device/subscribe";
var subcribeUrl = serverURL + "/secure/mdm/validate/user";
var fileUploadUrl = serverURL + "/secure/upload/file";
var getSettingsUrl = mdmServerURL + "/get/device/settings";
var getCallBackUrl =
  mdmServerURL + "/commands/status/completed?productName=" + resellerId;

//console.debug('DeviceIdOfTheDirectoryAPI', chrome.instanceID.getID());
