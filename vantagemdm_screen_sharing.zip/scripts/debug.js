/* 	https://server.remotebeam.com/secure/upload/file

	FileName: ->   mappingID-DEBUGLOG-timestamp.txt

	2b7a3d71-578d-476a-9ed6-1252d69ac721-DEBUGLOG-20190724120341.txt
*/

async function uploadDebugLogs() {
  let extensionLogs = await storage.get("extensionLogs");
  await storage.set("tmpLogs", extensionLogs);
  await storage.set("extensionLogs", "");

  this.uploadDebugLogsToServer();
}

async function uploadDebugLogsToServer() {
  let mappingId = await storage.get("mappingId");
  let tmpLogs = await storage.get("tmpLogs");
  let extensionLogs = await storage.get("extensionLogs");

  let fileName = mappingId + "-DEBUGLOG-" + time.accessTime() + ".txt";

  storage.set(
    "tmpLogs",
    tmpLogs +
      time.getCurrentDateTime(true) +
      " - uploading debuglog file " +
      fileName +
      " \r\n"
  );

  let content =
    "==== " +
    new Date().toLocaleString() +
    " File Name : " +
    fileName +
    " ====  \r\n";
  content += "===================================================\r\n";
  content += tmpLogs;

  var formData = new FormData();
  formData.append("serverFileName", fileName);
  formData.append(
    "file",
    new Blob([content], { type: "application/octet-stream" }),
    fileName
  );

  fetch(fileUploadUrl, {
    method: "POST",
    body: formData,
  })
    .then(function (response) {
      if (!response.ok) {
        throw new Error(
          "Error: " + response.status + " " + response.statusText
        );
      }
      clearLogsFromCache();
      storage.set(
        "extensionLogs",
        extensionLogs +
          time.getCurrentDateTime(true) +
          " - server response on uploading debuglog file " +
          fileName +
          " " +
          JSON.stringify(response) +
          " \r\n"
      );
      return response.text();
    })
    .then(async function (data) {
      try {
        let obj = JSON.parse(data);
        helpers.customConsoleLog(
          "debug.js",
          ["uploadDebugLogsToServer", "SERVER RESPONSE: " + obj.code],
          true
        );
      } catch (ex) {
        await storage.set(
          "extensionLogs",
          extensionLogs +
            time.getCurrentDateTime(true) +
            " - exception while uploading debuglog file " +
            fileName +
            " " +
            ex +
            " \r\n"
        );
        helpers.customConsoleLog(
          "debug.js",
          ["uploadDebugLogsToServer", "SERVER RESPONSE: " + ex],
          true
        );
      }
    })
    .catch(function (error) {
      helpers.customConsoleLog(
        "debug.js",
        ["uploadDebugLogsToServer", "SERVER RESPONSE: " + error.message],
        true
      );
    });
}

function formatFileSize(bytes, decimalPoint) {
  var FileSize = bytes / 1024 / 1024; // in MB
  if (FileSize > 1 && FileSize < 2) {
    helpers.customConsoleLog(
      "debug.js",
      [
        "formatFileSize",
        "uploading debuglog file. File Size : " + bytes + " bytes",
      ],
      true
    );

    uploadDebugLogs();
  } else if (FileSize > 2) {
    clearLogsFromCache();

    helpers.customConsoleLog(
      "debug.js",
      [
        "formatFileSize",
        "File size exceeds 2 MB. File Size : " + bytes + " bytes",
      ],
      true
    );
  } else {
    helpers.customConsoleLog(
      "debug.js",
      [
        "formatFileSize",
        "File saved successfully. File Size is : " + bytes + " bytes",
      ],
      true
    );
  }
}
async function saveLogsIntoCache(appendLog) {
  let extensionLogs = await storage.get("extensionLogs");
  let debugLogStatus = await storage.get("debugLogStatus");
  // var extensionLogs = storage.get("extensionLogs");
  // var debugLogStatus = storage.get("debugLogStatus");
  if (
    debugLogStatus == null ||
    debugLogStatus == "" ||
    debugLogStatus.toUpperCase() == "ENABLE"
  ) {
    let updatedLog = "";
    if (extensionLogs == null || extensionLogs == "") {
      updatedLog = appendLog;
    } else {
      updatedLog = extensionLogs + appendLog;
    }
    //var updatedLog=extensionLogs+appendLog;
    await storage.set("extensionLogs", updatedLog);

    helpers.customConsoleLog(
      "debug.js",
      ["saveLogsIntoCache", "extensionLogs", updatedLog],
      true
    );
    formatFileSize(updatedLog.length, 2);
  }
}
async function clearLogsFromCache() {
  await storage.set("tmpLogs", "");
}
async function createLocalStorageLog(appendLog) {
  /*CHECK SAVED LOG FIRST*/

  let extensionLogs = await storage.get("extensionLogs");

  let updatedLog = extensionLogs + appendLog;
  if (updatedLog) {
    /*CHECK SIZE*/
    /*IF LESS THAN 3MB */
    if (formatFileSize(updatedLog.length, 2)) {
      console.log("OK LOG " + updatedLog.length);
      helpers.customConsoleLog(
        "debug.js",
        ["createLocalStorageLog", "OK LOG " + updatedLog.length],
        true
      );
      /*UPLOAD THE FILE TO SERVER AND CLEAR ON SUCCESS*/
      await storage.set("extensionLogs", "");
    } else {
      helpers.customConsoleLog(
        "debug.js",
        ["createLocalStorageLog", "SIZE GREATER LOG"],
        true
      );
      /*CLEAR OLD CACHE AND SAVE NEW LOG INTO CACHE*/
      await storage.set("extensionLogs", appendLog);
    }
  } else {
    await storage.set("extensionLogs", appendLog);
    helpers.customConsoleLog(
      "debug.js",
      ["createLocalStorageLog", "ELSE LOGS ", appendLog],
      false
    );
  }
}
