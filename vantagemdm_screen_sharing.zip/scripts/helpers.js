var helpers = {
  processUrl: function (url) {
    // Remove "www." from the url.
    //url = url.replace("www.", "");

    // Some predefined.
    rule = "Not Defined";
    domain = url;
    plain_url = url;

    // If "://" found in url. seprate rule and domain.
    if (url.indexOf("://") > -1) {
      rule = url.split("://")[0];
      plain_url = url.split("://")[1];

      // Stripping main domain from full URL.
      if (plain_url.indexOf("/") > -1) domain = plain_url.split("/")[0];
      else domain = plain_url;
    } else {
      // Condition will execute if "://" not in URL.
      if (plain_url.indexOf("/") > -1) domain = plain_url.split("/")[0];
      else domain = plain_url;
    }
    return domain;
  },

  isValidJson: function isValidJson(json) {
    if (typeof json === "string") {
      try {
        helpers.customConsoleLog(
          "helpers.js",
          ["isValidJson", "string", json],
          false
        );

        JSON.parse(json);
        return true;
      } catch (error) {
        helpers.customConsoleLog(
          "helpers.js",
          ["isValidJson", "string", error],
          true
        );

        return false;
      }
    } else if (typeof json === "object" && json !== null) {
      try {
        helpers.customConsoleLog(
          "helpers.js",
          ["isValidJson", "object", json],
          false
        );
        JSON.stringify(json);
        return true;
      } catch (error) {
        helpers.customConsoleLog(
          "helpers.js",
          ["isValidJson", "object", error],
          false
        );
        return false;
      }
    }
    return false;
  },
  customConsoleLog: function (event, logMessage, isLog = true) {
    if (isLog === true) {
      console.log(event, JSON.stringify(logMessage));
    }
  },
  //Get parameter by name
  getParameterByName: function (name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  },
  /*
   *Function to add delay
   */
  wait: function (ms) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
      end = new Date().getTime();
    }
  },
};
