document.addEventListener("DOMContentLoaded", async function () {
  helpers.customConsoleLog("page.js", "DOMContentLoaded", true);
  let currentScreenCastingModeObj = await chrome.storage.local.get(
    "currentScreenCastingMode"
  );
  let currentScreenCastingMode =
    currentScreenCastingModeObj.currentScreenCastingMode;
  console.log("currentScreenCastingMode", currentScreenCastingMode);
  if (currentScreenCastingMode === true) {
    document.querySelector(".content").innerHTML =
      "<h2>Screen Sharing is <strong>Enabled</strong></h2><div><p style='padding:20px;'><span>Thank you for your interest in VantageMDM.</span></p></p>";
  } else {
    let serialKey = "";

    try {
      chrome.system.cpu.getInfo(function (cpuInfo) {
        var serialNumber = cpuInfo.serialNumber;
        console.log("serialNumber", serialNumber);
        serialKey = serialNumber;
        //$(".serialKey").html(serialNumber);
        var jsonData = "";
        var jsonObject = {
          userName: "",
          password: serialKey,
          resellerId: "VantageMDM",
          deviceKey: deviceKey,
          platform: platform,
          productVersion: buildVersion,
          productName: resellerId,
          timeZoneOffset: 0,
          udid: deviceKey,
          ChromeVersion: ChromeVersion,
          serial: ChromeVersion,
          enrollmentMode: "GOOGLE_CHROME_BOOK",
          agent: agent,
          browser: browser,
        };
        var formData = JSON.stringify(jsonObject);
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
        var urlencoded = new URLSearchParams();
        urlencoded.append("formData", formData);
        var requestOptions = {
          method: "POST",
          headers: myHeaders,
          body: urlencoded,
          redirect: "follow",
        };

        console.log("subcribeUrl", subcribeUrl, requestOptions);
        helpers.customConsoleLog(
          "page.js",
          ["subcribeUrl", subcribeUrl, requestOptions],
          false
        );
        fetch(subcribeUrl, requestOptions)
          .then(function (response) {
            helpers.customConsoleLog("page.js", ["response", response], false);
            if (!response.ok) {
              throw new Error("Something went wrong, Please try again.");
            }
            return response.json();
          })
          .then(async function (html) {
            saveLogsIntoCache(
              getCurrentDateTime(true) +
                " - response from server " +
                JSON.stringify(html) +
                ".\r\n"
            );
            var obj = html;
            try {
              widgetBoxOverlayElements.forEach(function (element) {
                element.remove();
              });
              if (obj.code == 100) {
                jsonData = {
                  mappingId: obj.mappingId,
                  code: obj.code,
                  screenCastingURL: obj.screenCastingURL,
                  rtmpUrl: obj.rtmpUrl,
                  deviceId: obj.deviceId,
                  mdmUrl: obj.mdmUrl,
                  deviceName: $("#email").val(),
                  deviceKey: obj.deviceKey,
                  productVersion: buildVersion,
                  protocol: obj.protocol,
                  port: obj.port,
                  host: obj.host,
                  streamMode: obj.streamMode,
                  companyUrl: obj.companyUrl,
                  companyName: obj.companyName,
                };
                await storage.set("mappingData", JSON.stringify(jsonData));
                await storage.set("mappingId", obj.mappingId);
                await storage.set("deviceKey", obj.deviceKey);
                await storage.set("currentScreenCastingMode", true);

                document.querySelector(".content").innerHTML =
                  "<h2>Screen Sharing is <strong>Enabled</strong></h2><div><p style='padding:20px;'><span>Thank you for your interest in VantageMDM.</span></p>";

                chrome.runtime.sendMessage({
                  method: "load_settings",
                  value: "",
                });
              } else if (obj.code == 301) {
                document.querySelector(".content").innerHTML =
                  "<a class='error'>Invalid serial key supplied.</a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";

                await storage.set("mappingData", false);

                await storage.set("currentScreenCastingMode", false);
              } else if (obj.code == 414 || obj.code == 430) {
                document.querySelector(".content").innerHTML =
                  "<a class='error'>Device is not enrolled / exist.</a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";

                await storage.set("mappingData", false);
                await storage.set("currentScreenCastingMode", false);
              } else {
                await storage.set("mappingData", false);
                await storage.set("currentScreenCastingMode", false);

                document.querySelector(".content").innerHTML =
                  "<a class='error'></a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";
              }
            } catch (ex) {
              document.querySelector(".content").innerHTML =
                '<div class="alert-error">Something went wrong, Please try again.</div>';
              await storage.set("mappingData", false);
              await storage.set("currentScreenCastingMode", false);

              widgetBoxOverlayElements.forEach(function (element) {
                element.remove();
              });
            }
          })
          .catch(async function (error) {
            console.log("ERROR 123: " + error);
            document.querySelector(".content").innerHTML =
              '<div class="alert-error">Something went wrong, Please try again.</div>';
            await storage.set("mappingData", false);
            await storage.set("currentScreenCastingMode", false);
          });
      });
    } catch (ex) {
      //console.log("EXCEPTION", ex.stack);
    }

    chrome.runtime.sendMessage(
      { action: "get-bookmarks" },
      function (response) {
        helpers.customConsoleLog(
          "page.js",
          ["serialKey in bookmarks block", response],
          true
        );

        if (serialKey == "") {
          if (typeof response.bookmarks.length !== "undefined") {
            console.log("testData", "undefined", response.bookmarks);
            if (response.bookmarks.length == 0) {
              /* document.querySelector(".content").innerHTML =
                "<h2>Welcome to VantageMDM Screen Sharing</h2><div><p style='padding:20px;'><span>Click following button to connect with VantageMDM</span></p><p class='prominent'><a href='/views/page.html' class='btn btn--sm'>Connect</a></p>";*/
              //location.href = chrome.extension.getURL("views/page.html");

              document.querySelector(".content").innerHTML =
                "<h2>Welcome to VantageMDM Screen Sharing</h2><div><p ><a class='error'></a></p><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";

              helpers.customConsoleLog("page.js", ["response", response], true);
            }

            if (response.bookmarks.length > 0) {
              var widgetBoxOverlayElements = document.querySelectorAll(
                ".widget-box-overlay"
              );
              const results = getFilteredResults(
                searchTerm,
                response.bookmarks
              );
              helpers.customConsoleLog(
                "page.js",
                ["bookmarks.length>0", response.bookmarks.length],
                true
              );
              console.log("results2", results);
              if (results.length == 1) {
                for (let i = 0; i < results.length; i++) {
                  const bookmark = results[i];
                  const urlTokens = bookmark.url.split("/", 4);
                  serialKey = urlTokens[3];
                  console.log("serialKey=", serialKey);

                  let jsonData = "";
                  let jsonObject = {
                    userName: "",
                    password: serialKey,
                    resellerId: "VantageMDM",
                    deviceKey: deviceKey,
                    platform: platform,
                    productVersion: buildVersion,
                    productName: resellerId,
                    timeZoneOffset: 0,
                    udid: deviceKey,
                    ChromeVersion: ChromeVersion,
                    serial: ChromeVersion,
                    //  enrollmentMode: "GOOGLE_CHROME_BOOK",
                    agent: agent,
                    browser: browser,
                  };
                  var formData = JSON.stringify(jsonObject);
                  var myHeaders = new Headers();
                  myHeaders.append(
                    "Content-Type",
                    "application/x-www-form-urlencoded"
                  );
                  var urlencoded = new URLSearchParams();
                  urlencoded.append("formData", formData);
                  var requestOptions = {
                    method: "POST",
                    headers: myHeaders,
                    body: urlencoded,
                    redirect: "follow",
                  };

                  console.log("subcribeUrl", subcribeUrl, requestOptions);
                  helpers.customConsoleLog(
                    "page.js",
                    ["subcribeUrl", subcribeUrl, requestOptions],
                    false
                  );
                  fetch(subcribeUrl, requestOptions)
                    .then(function (response) {
                      helpers.customConsoleLog(
                        "page.js",
                        ["response", response],
                        false
                      );
                      if (!response.ok) {
                        throw new Error(
                          "Something went wrong, Please try again."
                        );
                      }
                      return response.json();
                    })
                    .then(async function (html) {
                      saveLogsIntoCache(
                        getCurrentDateTime(true) +
                          " - response from server " +
                          JSON.stringify(html) +
                          ".\r\n"
                      );
                      var obj = html;
                      try {
                        widgetBoxOverlayElements.forEach(function (element) {
                          element.remove();
                        });
                        if (obj.code == 100) {
                          jsonData = {
                            mappingId: obj.mappingId,
                            code: obj.code,
                            screenCastingURL: obj.screenCastingURL,
                            rtmpUrl: obj.rtmpUrl,
                            deviceId: obj.deviceId,
                            mdmUrl: obj.mdmUrl,
                            deviceName: $("#email").val(),
                            deviceKey: obj.deviceKey,
                            productVersion: buildVersion,
                            protocol: obj.protocol,
                            port: obj.port,
                            host: obj.host,
                            streamMode: obj.streamMode,
                            companyUrl: obj.companyUrl,
                            companyName: obj.companyName,
                          };
                          await storage.set(
                            "mappingData",
                            JSON.stringify(jsonData)
                          );
                          await storage.set("mappingId", obj.mappingId);
                          await storage.set("deviceKey", obj.deviceKey);
                          await storage.set("currentScreenCastingMode", true);

                          document.querySelector(".content").innerHTML =
                            "<h2>Screen Sharing is <strong>Enabled</strong></h2><div><p style='padding:20px;'><span>Thank you for your interest in VantageMDM.</span></p>";

                          chrome.runtime.sendMessage({
                            method: "load_settings",
                            value: "",
                          });
                        } else if (obj.code == 301) {
                          document.querySelector(".content").innerHTML =
                            "<a class='error'>Invalid serial key supplied.</a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";

                          await storage.set("mappingData", false);

                          await storage.set("currentScreenCastingMode", false);
                        } else if (obj.code == 414 || obj.code == 430) {
                          document.querySelector(".content").innerHTML =
                            "<a class='error'>Device is not enrolled / exist.</a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";

                          await storage.set("mappingData", false);
                          await storage.set("currentScreenCastingMode", false);
                        } else {
                          await storage.set("mappingData", false);
                          await storage.set("currentScreenCastingMode", false);

                          document.querySelector(".content").innerHTML =
                            "<a class='error'></a><div id='signin'><form class='signup-form'><div class='div-input'><input type='text' name='serialKey' id='serialKey' maxlength='128' placeholder='Serial Key' required=''></div><div class='div-input'><button type='button' class='btn btn--sm' id='submit_signin'>Connect</button></div></form></div>";
                        }
                      } catch (ex) {
                        document.querySelector(".content").innerHTML =
                          '<div class="alert-error">Something went wrong, Please try again.</div>';
                        await storage.set("mappingData", false);
                        await storage.set("currentScreenCastingMode", false);

                        widgetBoxOverlayElements.forEach(function (element) {
                          element.remove();
                        });
                      }
                    })
                    .catch(async function (error) {
                      console.log("ERROR 123: " + error);
                      document.querySelector(".content").innerHTML =
                        '<div class="alert-error">Something went wrong, Please try again.</div>';
                      await storage.set("mappingData", false);
                      await storage.set("currentScreenCastingMode", false);
                    });
                }
                //isvantageMDMAutoFill = localStorage.getItem("vantageMDMConnect");
              }
            } else {
              var serialKeyElement = document.querySelector(".serialKey");
              if (serialKeyElement !== null) {
                document.querySelector(".serialKey").innerHTML = "";
              }
            }
          } else {
            console.log("get-bookmarks", "serialKey else");
            var serialKeyElement = document.querySelector(".serialKey");
            if (serialKeyElement !== null) {
              document.querySelector(".serialKey").innerHTML = "";
            }
          }
        }
      }
    );
  }

  const getFilteredResults = function (searchTerm, bookmarks) {
    let matches = [];
    let currentFilteredResultsCount = 0;
    searchTerm = searchTerm.toLowerCase();

    for (let i = 0; i < bookmarks.length; i++) {
      let bookmark = bookmarks[i];

      if (
        bookmark.url.indexOf(searchTerm) !== -1 ||
        bookmark.title.indexOf(searchTerm) !== -1
      ) {
        currentFilteredResultsCount++;

        if (
          true ||
          currentFilteredResultsCount < maxAllowedFilteredResultCount
        ) {
          matches.push(bookmark);
        }
      }
    }

    return matches;
  };
});

document.addEventListener("click", function (event) {
  if (event.target.classList.contains("close")) {
    window.close();
  }
});

document.addEventListener("click", function (event) {
  var widgetBoxOverlayElements = document.querySelectorAll(
    ".widget-box-overlay"
  );

  if (event.target.matches("#submit_signin")) {
    if (document.querySelector("#serialKey").value === "") {
      document.querySelector("#serialKey").classList.add("highlight-error");
      document.querySelector(".error").innerHTML = "Please enter serial key.";
    } else {
      document.querySelector("#serialKey").classList.remove("highlight-error");
      document.querySelector(".error").innerHTML = "";

      let jsonData = "";
      let jsonObject = {
        userName: "",
        password: $("#serialKey").val(),
        resellerId: "VantageMDM",
        deviceKey: deviceKey,
        platform: platform,
        productVersion: buildVersion,
        productName: resellerId,
        timeZoneOffset: 0,
        udid: deviceKey,
        ChromeVersion: ChromeVersion,
        serial: ChromeVersion,
        agent: agent,
        browser: browser,
      };
      var formData = JSON.stringify(jsonObject);
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
      var urlencoded = new URLSearchParams();
      urlencoded.append("formData", formData);
      var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: urlencoded,
        redirect: "follow",
      };
      helpers.customConsoleLog("page.js", [subcribeUrl, requestOptions], false);

      fetch(subcribeUrl, requestOptions)
        .then(function (response) {
          console.log("response", response);
          if (!response.ok) {
            throw new Error("Something went wrong, Please try again.");
          }
          return response.json();
        })
        .then(async function (html) {
          document.querySelector("#submit_signin").innerHTML = "Sign In";

          saveLogsIntoCache(
            getCurrentDateTime(true) +
              " - response from server " +
              JSON.stringify(html) +
              ".\r\n"
          );
          var obj = html;
          try {
            widgetBoxOverlayElements.forEach(function (element) {
              element.remove();
            });
            if (obj.code == 100) {
              jsonData = {
                mappingId: obj.mappingId,
                code: obj.code,
                screenCastingURL: obj.screenCastingURL,
                rtmpUrl: obj.rtmpUrl,
                deviceId: obj.deviceId,
                mdmUrl: obj.mdmUrl,
                deviceName: $("#email").val(),
                deviceKey: obj.deviceKey,
                productVersion: buildVersion,
                protocol: obj.protocol,
                port: obj.port,
                host: obj.host,
                streamMode: obj.streamMode,
                companyUrl: obj.companyUrl,
                companyName: obj.companyName,
              };
              await storage.set("mappingData", JSON.stringify(jsonData));
              await storage.set("mappingId", obj.mappingId);
              await storage.set("deviceKey", obj.deviceKey);
              await storage.set("currentScreenCastingMode", true);

              document.querySelector(".content").innerHTML =
                "<h2>Screen Sharing is <strong>Enabled</strong></h2><div><p style='padding:20px;'><span>Thank you for your interest in VantageMDM.</span></p>";

              chrome.runtime.sendMessage({
                method: "load_settings",
                value: "",
              });
            } else if (obj.code == 301) {
              document.querySelector(".error").innerHTML =
                '<div class="alert-error">Invalid serial key supplied.</div>';

              await storage.set("mappingData", false);
              await storage.set("currentScreenCastingMode", false);
            } else if (obj.code == 414 || obj.code == 430) {
              document.querySelector(".error").innerHTML =
                '<div class="alert-error">Device is not enrolled / exist.</div>';

              await storage.set("mappingData", false);
              await storage.set("currentScreenCastingMode", false);
            } else {
              document.querySelector(".error").innerHTML =
                '<div class="alert-error">Something went wrong, Please try again.</div>';

              await storage.set("mappingData", false);
              await storage.set("currentScreenCastingMode", false);
            }
          } catch (ex) {
            document.querySelector(".error").innerHTML =
              '<div class="alert-error">Something went wrong, Please try again.</div>';
            await storage.set("mappingData", false);
            await storage.set("currentScreenCastingMode", false);

            widgetBoxOverlayElements.forEach(function (element) {
              element.remove();
            });
          }
        })
        .catch(async function (error) {
          helpers.customConsoleLog("page.js", ["error", error], true);
          document.querySelector(".error").innerHTML =
            '<div class="alert-error">Something went wrong, Please try again.</div>';
          await storage.set("mappingData", false);
          await storage.set("currentScreenCastingMode", false);
        });
    }
  }
});

function getCurrentDateTime(a) {
  var currentDate = new Date();
  var dateString = currentDate.getFullYear().toString();

  var month = (currentDate.getMonth() + 1).toString().padStart(2, "0");
  var day = currentDate.getDate().toString().padStart(2, "0");
  var hours = currentDate.getHours().toString().padStart(2, "0");
  var minutes = currentDate.getMinutes().toString().padStart(2, "0");
  var seconds = currentDate.getSeconds().toString().padStart(2, "0");

  dateString +=
    "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;

  if (a) {
    var milliseconds = currentDate
      .getMilliseconds()
      .toString()
      .padStart(3, "0");
    dateString += "." + milliseconds + "000";
  }

  return dateString;
}
