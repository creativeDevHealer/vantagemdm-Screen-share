class Popup {
  constructor() {
    var self = this;
    // Message port
    self.port = null;
    // Is streaming started or no
    self.started = false;
    // Actual status message
    self.message = null;
    // Is there any error?
    self.hasError = false;
    var vantageScreenStartBtn = document.getElementById(
      "vantageScreenStartBtn"
    );
    var vantageScreenStopBtn = document.getElementById("vantageScreenStopBtn");
    vantageScreenStartBtn.addEventListener("click", function () {
      self.videoStart();
    });
    vantageScreenStopBtn.addEventListener("click", function () {
      self.videoStop();
    });
    // Init messaging
    //self.port = chrome.runtime.connect({ name: "VideoStreamer" });
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      try {
        console.log("response_pop", msg);
        var data = JSON.parse(msg);
        // Start streaming
        if (data.action == "start") {
          self.hasError = false;
          // Stop streaming
        } else if (data.action == "stop") {
          // when videos stopped from outside popup
          self.videoStop();

          var data = { action: "message", message: "stop" };
          chrome.tabs.query(
            { active: true, currentWindow: true },
            function (tabs) {
              chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
            }
          );
        } else if (data.action == "status") {
          if (data.status == "idle") {
            self.started = false;
            self.init();
          } else {
            self.started = true;
          }

          self.showStatus();
          // Status messages
        } else if (data.action == "message" && data.code == 403) {
          // when user cancel to publish video
          self.videoStop();
        } else if (data.action == "message") {
          self.message = data.message;
          if (data.error) {
            self.error(data.error);
          } else {
            /*CUSTOM CHECK*/
            if (self.message == "stop") {
              self.videoStop();
              var data = { action: "message", message: "stop" };
              chrome.tabs.query(
                { active: true, currentWindow: true },
                function (tabs) {
                  chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
                }
              );
            } else {
              self.showStatus();
            }
          }
        }
      } catch (e) {
        console.warn(e.message);
      }
    });
    // Request backend status — if we streaming now or not
    var data = { action: "status" };

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
    });

    setInterval(() => {
      var data = { action: "status" };

      console.log("BLOCK 3 SECOND =>  POPUP.JS : " + JSON.stringify(data));

      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
          const tab = tabs[0];

          let isValidUrlOrFilePath = self.isValidUrlOrFilePath(tab.url);
          var screenCastingMessage = document.querySelector(
            ".screenCastingMessage"
          );

          if (isValidUrlOrFilePath == true) {
            screenCastingMessage.innerHTML =
              "Please use following buttons to start/stop streaming.";
            if (self.message == "stop") {
              document.getElementById("progress").style.display = "block";
              document.getElementById("vantageScreenStartBtn").style.display =
                "inline";
              document.getElementById(
                "vantageScreenStartBtn"
              ).style.opacity = 0.2;
              document.getElementById("vantageScreenStopBtn").style.display =
                "inline";
              document.getElementById("vantageScreenStopBtn").style.opacity = 1;
            } else {
              document.getElementById("progress").style.display = "none";
              document.getElementById("vantageScreenStartBtn").style.display =
                "inline";
              document.getElementById(
                "vantageScreenStartBtn"
              ).style.opacity = 1;
              document.getElementById("vantageScreenStopBtn").style.display =
                "inline";
              document.getElementById(
                "vantageScreenStopBtn"
              ).style.opacity = 0.2;
            }
          } else {
            screenCastingMessage.innerHTML =
              "Please open any valid URL to enable Screen Sharing.";
          }
        }

        chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
      });
    }, 3000);
    // Init popup
    self.init();
  }

  /**
   * Initialize popup
   *
   */
  init() {
    var self = this;
    self.errorHide();
    // Do any preparing tasks here
  }

  /**
   * Change buttons/badge status — if streaming or not
   *
   */
  showStatus() {
    var self = this;
    if (self.hasError) {
      return false;
    }
    switch (self.message) {
      case "ready":
        var message = "Ready for streaming";
        break;
      case "waiting":
        var message = "Waiting for viewer";
        break;
      case "streaming":
        var message = "Streaming in progress";
        break;
      default:
        var message = null;
    }
    //alert(message)
    if (!message) {
      //alert(message)
      //document.getElementById('status').style.display = 'none';
      document.getElementById("status").innerHTML = "Ready for streaming";
    } else {
      document.getElementById("status").style.display = "block";
      document.getElementById("status").innerHTML = message;
    }
    if (!self.started) {
      document.getElementById("progress").style.display = "none";
      document.getElementById("vantageScreenStartBtn").style.display = "inline";
      document.getElementById("vantageScreenStartBtn").style.opacity = 1;
      document.getElementById("vantageScreenStopBtn").style.display = "inline";
      document.getElementById("vantageScreenStopBtn").style.opacity = 0.2;
    } else {
      document.getElementById("progress").style.display = "block";
      document.getElementById("vantageScreenStartBtn").style.display = "inline";
      document.getElementById("vantageScreenStartBtn").style.opacity = 0.2;
      document.getElementById("vantageScreenStopBtn").style.display = "inline";
      document.getElementById("vantageScreenStopBtn").style.opacity = 1;
    }
  }

  /**
   * Start streaming
   *
   */
  videoStart() {
    var self = this;
    // If started - do nothing
    if (self.started) {
      return false;
    }
    self.started = true;
    // Send message to background.js
    var data = { action: "start" };
    // self.port.postMessage(JSON.stringify(data));
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
    });
    // Update interface
    self.showStatus();
  }

  /**
   * Stop  streaming
   *
   */
  videoStop() {
    console.log("videoStop");
    var self = this;
    // Not streaming now - do nothing
    if (!self.started) {
      return false;
    }
    self.started = false;
    // Update interface
    self.showStatus();
    // Send message to background.js
    var data = { action: "stop" };
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
    });
  }

  /**
   * Error reporting
   *
   * @param message    string      error message
   */
  error(message) {
    //alert("error");
    var self = this;
    self.started = false;
    self.hasError = true;
    document.getElementById("error").innerHTML = message;
    document.getElementById("error").style.display = "block";
    document.getElementById("vantageScreenStartBtn").style.display = "none";
    document.getElementById("vantageScreenStopBtn").style.display = "none";
    document.getElementById("status").style.display = "none";
    document.getElementById("progress").style.display = "none";
  }

  /**
   * Hide error message
   *
   */
  errorHide() {
    var self = this;
    self.hasError = false;
    document.getElementById("error").style.display = "none";
  }

  isValidUrlOrFilePath(input) {
    // Get the current active tab

    if (input) {
      // console.log("abc url", input);
      const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;

      // Regular expression for local file path validation
      const filePathRegex = /^file:\/\/\/\w:[\\/].*$/i;

      if (urlRegex.test(input)) {
        // Valid URL
        console.log("abc valid url");
        return true;
      } else if (filePathRegex.test(input)) {
        //  console.log("abc valid path");
        // Valid local file path
        return true;
      } else {
        // Invalid URL or local file path
        return false;
      }
    } else {
      console.log("abc invalid url");
      return false;
    }
  }
}

var popupJs = "";
document.addEventListener("DOMContentLoaded", async function () {
  let currentScreenCastingModeObj = await chrome.storage.local.get(
    "currentScreenCastingMode"
  );
  let currentScreenCastingMode =
    currentScreenCastingModeObj?.currentScreenCastingMode;
  if (currentScreenCastingMode === true) {
    popupJs = new Popup();

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs.length > 0) {
        const tab = tabs[0];

        let isValidUrlOrFilePath = popupJs.isValidUrlOrFilePath(tab.url);
        var screenCastingMessage = document.querySelector(
          ".screenCastingMessage"
        );

        if (isValidUrlOrFilePath == true) {
          screenCastingMessage.innerHTML =
            "Please use following buttons to start/stop streaming.";
        } else {
          screenCastingMessage.innerHTML =
            "Please open any valid URL to enable Screen Sharing.";
        }
      }

      chrome.tabs.sendMessage(tabs[0].id, JSON.stringify(data));
    });
  } else {
    chrome.tabs.create({ url: "/views/page.html" });
  }
});
