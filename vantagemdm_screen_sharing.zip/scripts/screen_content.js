var self = this;
// Client id
self.id = ""; //localStorage.getItem("mappingId");

// Signaling server url

self.socketUrl = socketUrl;
// Socket Connect Error
self.socket_connect_error = false;
// Socket object
self.socket = null;
// Media stream with screen video
self.mediaStream = null;
// RTCPeerConnection
self.connection = null;
// Buffer for incoming ICE candidates
self.inCandidates = [];
// Buffer for outgoing ICE candidates
self.outCandidates = [];
// If answer is received and we can assign incoming ICE candidates to
// RTCPeerConnection
self.answerReceived = false;
// Streaming status
self.status = "idle"; // idle, progress, reconnect, error
// Streaming status
self.viewer = null;
// Message for popup
self.message = null;
// Message port
self.port = null;
// If it's first run of extension
self.firstRun = false;
// Connect to port to listen messages
//chrome.runtime.onConnect.addListener(function (port) {

// self.port = port;
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  try {
    var data = JSON.parse(msg);
    helpers.customConsoleLog("content.js", ["onMessage", data], false);

    // Start streaming
    if (data.action == "start") {
      //alert('ACTION : ' + JSON.stringify(data))
      self.status = "progress";
      self.initStreaming();
      var data = { action: "start" };
      chrome.runtime.sendMessage(JSON.stringify(data));
      // Stop streaming
    } else if (data.action == "stop") {
      self.status = "idle";
      self.stopStreaming();
      var data = { action: "stop" };
      chrome.runtime.sendMessage(JSON.stringify(data));

      // Get status
    } else if (data.action == "status") {
      /*2 MESSAGES POST FROM THIS BLOCK*/
      var data = { action: "status", status: self.status };

      helpers.customConsoleLog("content.js", ["onMessage status", data], false);
      chrome.runtime.sendMessage(JSON.stringify(data));

      var data = { action: "message", message: self.message };
      chrome.runtime.sendMessage(JSON.stringify(data));
    }
  } catch (e) {
    helpers.customConsoleLog(
      "content.js",
      ["onMessage error", e.message],
      true
    );
  }
});
// Not furst run? It means user reloaded page or just closed / opened popup.
// Send status message to popup
if (!self.firstRun) {
  self.firstRun = true;
  self.message = "ready";

  var data = { action: "message", message: self.message };
  try {
    helpers.customConsoleLog("content.js", ["FISRT RUN Block", data], false);

    chrome.runtime.sendMessage(JSON.stringify(data));

    if (browser === "Chromium") {
      setInterval(async () => {
        var data = { action: "status" };
        helpers.customConsoleLog(
          "content.js",
          ["BLOCK 5 SECOND CHROMIUM", data],
          true
        );

        /* check active command from storage start/stop?
         * also set current state into storage
         */
        let currentScreenCastingModeObj = await chrome.storage.local.get(
          "currentScreenCastingMode"
        );
        let currentScreenCastingMode =
          currentScreenCastingModeObj.currentScreenCastingMode;
        let settingsData = await storage.get("__settings");
        let CurrentCommandStatus = await storage.get("CurrentCommandStatus");
        screenRecordingAction = "";
        if (helpers.isValidJson(settingsData)) {
          settings = settingsData;

          helpers.customConsoleLog("content.js", ["settings", settings], false);
        }
        if (currentScreenCastingMode === true) {
          if (typeof settings.screenRecording !== "undefined") {
            if (typeof settings.screenRecording.action !== "undefined") {
              screenRecordingAction = settings.screenRecording.action;
            }
          }
        }
        helpers.customConsoleLog(
          "content.js",
          [
            "screenRecordingAction : " + screenRecordingAction,
            "CurrentCommandStatus : " + CurrentCommandStatus,
            "self.status :" + self.status,
          ],
          false
        );

        if (screenRecordingAction === "start" && self.status !== "progress") {
          //stop and start streaming and set ContentStatus

          //stop
          /*await storage.set("CurrentCommandStatus", "idle");
        self.status = "idle";
        self.stopStreaming();
        var data = { action: "stop" };
        chrome.runtime.sendMessage(JSON.stringify(data));
       */

          // start
          await storage.set("CurrentCommandStatus", "progress");

          self.status = "progress";
          self.initStreaming();
          var data = { action: "start" };
          chrome.runtime.sendMessage(JSON.stringify(data));
        } else if (screenRecordingAction === "stop" && self.status !== "idle") {
          //start streaming and set ContentStatus
          await storage.set("CurrentCommandStatus", "idle");
          self.status = "idle";
          self.stopStreaming();
          var data = { action: "stop" };
          chrome.runtime.sendMessage(JSON.stringify(data));
        }
      }, 5000);
    }
  } catch (e) {
    helpers.customConsoleLog("content.js", ["Not first ERROR" + e], true);
  }
}
//});

/**
 * Initialize screen capture
 *
 */
function initStreaming() {
  var self = this;
  // Init screen capturing and get permissions
  navigator.mediaDevices
    .getDisplayMedia({ audio: true, video: true })
    .then((mediaStreamDisplay) => {
      self.mediaStream = mediaStreamDisplay;
      // Start streaming
      self.startStreaming();
    })
    .catch((err) => {
      // User rejects screen sharing request
      var data = {
        action: "message",
        error: "getDisplayMedia failed: " + err.message,
        code: 403,
      };
      if (self.port) {
        try {
          chrome.runtime.sendMessage(JSON.stringify(data));

          //self.stopStreaming();
        } catch (e) {}
      }
    });
}

/**
 * Connect to signaling server and start streaming
 *
 */
function startStreaming() {
  var self = this;
  self.socket_connect_error = false;

  helpers.customConsoleLog("content.js", "Start streaming", false);

  // Connect to socket
  self.connect((err) => {
    // alert(err);
    self.answerReceived = false;
    // If RTCPeerConnection was initialized before — close it
    if (self.connection) {
      self.connection.close();
    }
    self.inCandidates = [];
    self.outCandidates = [];
    // Create RTCPeerConnection

    self.connection = new RTCPeerConnection({
      iceServers: self.iceServers,

      optional: {
        googCpuOveruseDetection: true,
        /* googCpuUnderuseThreshold: 90, */
        googCpuOverUseThreshold: 95,
      },
    });
    //alert(JSON.stringify(self.connection.getConfiguration()))
    // Add stream tracks to RTCPeerConnection
    self.mediaStream.getTracks().forEach((track) => {
      self.connection.addTrack(track, self.mediaStream);
    });
    // Local ICE candidate generated — send it to server
    self.connection.onicecandidate = (event) => {
      if (event.candidate) {
        // alert("answer : " + self.answerReceived + " " + JSON.stringify(event.candidate))
        helpers.customConsoleLog(
          "content.js",
          ["New candidate generated", event.candidate],
          true
        );

        // If answer is reseived — apply ICE candidated to connection
        // If not — store it and will apply in future
        if (self.answerReceived && false) {
          // A tiny delay to ensure that sdpOffer and sdpAnswer
          // were really delivered and applied at viewer's side
          var data = { stream: self.stream, message: event.candidate };
          //alert('/v1/sdp/ice')
          self.socket.emit("/v1/sdp/ice", data);
        } else {
          self.outCandidates.push(event.candidate);
        }
      }
    };
    // Generate sdpOffer
    self.connection
      .createOffer({
        offerToReceiveAudio: 1,
        offerToReceiveVideo: 1,
      })
      .then(
        (desc) => {
          desc.sdp = desc.sdp.replace(
            /a=mid:video\r\n/g,
            "a=mid:video\r\nb=AS:256\r\n"
          );
          // desc.sdp = desc.sdp.replace(/m=video.*?\r\n/, 'm=video 9 UDP/TLS/RTP/SAVPF 96 \r\n');
          // desc.sdp += "a=fmtp:96 x-google-max-bitrate=100000\r\n";
          // desc.sdp += "a=fmtp:96 x-google-start-bitrate=20000\r\n";
          // Apply it to RTCPeerConnection

          helpers.customConsoleLog("content.js", ["SDP", desc.sdp], true);
          self.connection.setLocalDescription(desc);
          // Send request to signaling server
          // Request includes sdpOffer, so we don't need to send it in a
          // separate message — make connection faster

          let data = { client: self.id, stream: self.stream, sdpOffer: desc };
          // alert(JSON.stringify(data))
          self.socket.emit("/v1/stream/start", data);

          // Send message to popup.html
          self.message = "waiting";
          data = { action: "message", message: self.message };
          if (self.port) {
            try {
              chrome.runtime.sendMessage(JSON.stringify(data));
            } catch (e) {}
          }

          // Change icon to blue — waiting for viewer
          //chrome.browserAction.setIcon({ path: 'icon-blue.png' })

          // set storage value start
          localStorage.setItem("screensharing", "start");
        },
        (error) => {
          helpers.customConsoleLog(
            "content.js",
            ["Error in create offer, desc.sdp", error],
            true
          );
        }
      );

    self.mediaStream.getVideoTracks()[0].addEventListener("ended", () => {
      //alert("hello");
      self.socket_connect_error = true;
      self.stopStreaming();

      /*
    var data = {'action': 'stop'};

    if (self.port) {
      try {
        chrome.runtime.sendMessage(JSON.stringify(data));
        //self.stopStreaming();
      } catch (e) {}
    }	
    */
    });
  });
}

/**
 * Stop streaming
 *
 */
function stopStreaming() {
  var self = this;

  helpers.customConsoleLog("content.js", ["stopStreaming"], false);
  // Close RTCPeerConnection
  if (self.connection) {
    self.connection.close();
  }
  // Release camera
  if (self.mediaStream) {
    var tracks = self.mediaStream.getTracks();
    for (let i in tracks) {
      tracks[i].stop();
    }
  }

  // Send message to popup
  self.message = "done";

  self.viewer = null;
  let data = "";
  if (self.socket_connect_error) {
    self.status = "idle";
    data = { action: "message", message: "stop" };
  } else {
    data = { action: "message", message: self.message };
  }
  if (self.port) {
    try {
      //alert(JSON.stringify(data));
      chrome.runtime.sendMessage(JSON.stringify(data));
    } catch (e) {}
  }
  // Send message to signaling server
  data = { stream: self.stream };
  self.socket.emit("/v1/stream/destroy", data);
  // Change icon
  //chrome.browserAction.setIcon({ path: 'icon.png' })

  // stop screen sharing
  localStorage.setItem("screensharing", "stop");
}

/**
 * Somebody statrs watching the stream
 */
function onStreamJoin(data) {
  helpers.customConsoleLog("content.js", ["onStreamJoin", data], true);
  let self = this;
  // Get stream ID
  self.stream = data.stream;
  self.viewer = true;
  // Set remote sdpAnswer. It's included in /v1/stream/joined message
  self.connection
    .setRemoteDescription(data.sdpAnswer)
    .then(() => {
      // Answer is received, we can assign ICE candidates to RTCPeerConnection
      self.answerReceived = true;
      // Append cached candidates
      for (let i in self.inCandidates) {
        if (self.inCandidates[i].candidate) {
          var candidate = new RTCIceCandidate(self.inCandidates[i]);
          self.connection.addIceCandidate(candidate);
        }
      }
      // Sent cached outgoing candidates
      for (let i in self.outCandidates) {
        var data = { stream: self.stream, message: self.outCandidates[i] };
        self.socket.emit("/v1/sdp/ice", data);
      }
      // Send message to popup
      self.message = "streaming";
      var data = { action: "message", message: self.message };
      // Change icon to red — viewer is here
      //chrome.browserAction.setIcon({ path: 'icon-red.png' })
    })
    .catch((e) => {
      helpers.customConsoleLog(
        "content.js",
        ["error on onStreamJoin", e],
        true
      );
    });
}

/**
 * Incoming ICE candidate received
 *
 * @param response   array   Response from signaling server
 */
function onIncomingICE(response) {
  var self = this;

  helpers.customConsoleLog(
    "content.js",
    ["Remote candidate onIncomingICE", response],
    true
  );
  //alert('Remote candidate ' + JSON.stringify(response))
  // Append it to connecion if both offer and answer was appended
  if (self.answerReceived) {
    if (response.message.candidate) {
      var candidate = new RTCIceCandidate(response.message);
      self.connection.addIceCandidate(candidate);
    }
    // ... or cache it
  } else {
    if (!self.inCandidates) {
      self.inCandidates = [];
    }
    self.inCandidates.push(response.message);
  }
}

/**
 * Watcher leaved your stream
 * We should restart our stream to make it available for next possible viewer
 */
function onStreamLeave() {
  let self = this;
  self.startStreaming();
}

/**
 * Connect to signaling server and itinialize events
 *
 * @param callback   function    Callback will be executed when conneciton is ready
 */
async function connect(callback) {
  var self = this;
  self.id = await storage.get("mappingId");

  if (self.socket) {
    return callback();
  }

  // Connection and Hello
  try {
    self.socket = new io(self.socketUrl, {
      query: "mappingId=" + self.id,
      secure: true,
      transports: ["websocket"],
    });
  } catch (e) {
    helpers.customConsoleLog("content.js", ["connect error", e], true);
  }

  self.socket.on("connect", () => {
    if (self.status == "reconnect") {
      if (self.viewer) {
        self.status = "progress";
        //chrome.browserAction.setIcon({path : 'icon-red.png'});
      } else {
        self.stopStreaming();
        self.startStreaming();
        //chrome.browserAction.setIcon({path : 'icon-blue.png'});
      }
    }
  });

  // Send ping requres to ensure that connection will remain alive
  setInterval((fake) => {
    try {
      self.socket.emit("/v1/alive");
    } catch (e) {}
  }, 10000);

  self.socket.on("connect", (socket) => {});

  // Socket connected? Ok, but it's not all — waiting for /v1/ready
  self.socket.on("reconnect_error", (socket) => {
    setTimeout(() => {
      self.connect(callback);
    }, 1000);
  });

  // Something fails?
  self.socket.on("connect_error", (error) => {
    self.socket.close();
    /*CUSTOM CHECK*/
    self.socket_connect_error = true;
    self.stopStreaming();
    alert(
      "Please check your device internet connection and turn on the stream again. If the problem still persists, please contact with our support."
    );
    /*CUSTOM END*/

    self.socket = null;
    if (self.status == "reconnect") {
      // self.connect(() => {})
    }
    self.logItSocket("Can`t connect to socket", error);
  });

  // Something fails?
  self.socket.on("error", (error) => {
    self.socket.close();
    self.socket = null;
    self.logItSocket("Can`t connect to socket", error);
  });

  // Handle disconnect
  self.socket.on("disconnect", (error) => {
    self.logItSocket("Disconnected1", error);
    self.socket.close();
    self.socket = null;
    if (self.status == "progress") {
      self.status = "reconnect";
      //chrome.browserAction.setIcon({path : 'icon-yellow.png'});
      setTimeout(() => {
        self.connect(() => {});
      }, 1000);
    }
    self.logItSocket("Disconnected2", error);
  });

  // Ready, steady, go...
  self.socket.on("/v1/ready", function (response) {
    // Assign ICE servers
    self.iceServers = response.iceServers;

    helpers.customConsoleLog(
      "content.js",
      ["Connection is ready to use", self.iceServers],
      true
    );
    callback();
  });

  // Start new stream
  self.socket.on("/v1/stream/start", function (response) {
    // There is no viewer at this time, we should just store stream ID
    self.stream = response.stream;
    self.logItSocket("/v1/stream/start", response);
  });

  // Destroy the room
  self.socket.on("/v1/stream/destroy", function (response) {
    // Do something after finishing the stream
    self.logItSocket("/v1/stream/destroy", response);
  });

  // User joined your stream
  self.socket.on("/v1/stream/joined", function (response) {
    self.onStreamJoin(response);
    self.logItSocket("/v1/stream/joined", response);
  });

  // User leaved your stream
  self.socket.on("/v1/stream/leaved", function (response) {
    self.onStreamLeave(response);
    self.logItSocket("/v1/stream/leaved", response);
  });

  // Incoming ICE candidate
  self.socket.on("/v1/sdp/peer_ice", function (response) {
    self.onIncomingICE(response);
    self.logItSocket("/v1/publisher/peer_ice", response);
  });

  // General error
  self.socket.on("/v1/error", function (response) {
    self.logItSocket("/v1/call/error", response);
  });
}

function logItSocket(message, data) {
  console.log(message, data);
}
