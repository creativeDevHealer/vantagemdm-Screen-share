/*
 * LocalStorage Functions. Getter and Setter.
 */

var item = "";
var storage = {
  get: async function (key) {
    try {
      const result = await getLocalData(key);
      helpers.customConsoleLog(
        "storage.js",
        ["Retrieved data", "key: " + key, "value : " + JSON.stringify(result)],
        false
      );

      return result;
    } catch (error) {
      // Handle the error case

      helpers.customConsoleLog(
        "storage.js",
        ["Retrieved data ", "error : " + error],
        true
      );
      throw error;
    }
  },

  set: async function (key, value) {
    try {
      const result = await setLocalData(key, value);
      helpers.customConsoleLog(
        "storage.js",
        ["Stored data", "key: " + key, "value : " + JSON.stringify(result)],
        false
      );

      return result;
    } catch (error) {
      // Handle the error case
      helpers.customConsoleLog(
        "storage.js",
        ["Stored data ", "error : " + error],
        true
      );
      throw error;
    }
  },
};

function getLocalData(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(key, (result) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(result[key]);
      }
    });
  });
}
function setLocalData(key, value) {
  let storedData = {
    [key]: value,
  };

  return new Promise((resolve, reject) => {
    chrome.storage.local.set(storedData, () => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);

      resolve(value);
    });
  });
}
