/*
* Time Functions.
*/
var time = {

  // accessTime ()
  accessTime: function(a) {
    var currentDate = new Date();
    var dateString = currentDate.getFullYear().toString();

    if( (currentDate.getMonth() + 1).toString().length == 1 ) {
      dateString += "0" + (currentDate.getMonth() + 1).toString();
    } else {
      dateString += (currentDate.getMonth() + 1).toString();
    }

    if( currentDate.getDate().toString().length == 1 ) {
      dateString += "0" + currentDate.getDate().toString();
    } else {
      dateString += currentDate.getDate().toString();
    }

    if( currentDate.getHours().toString().length == 1 ) {
      dateString += "0" + currentDate.getHours().toString();
    } else {
      dateString += currentDate.getHours().toString();
    }

    if( currentDate.getMinutes().toString().length == 1 ) {
      dateString += "0" + currentDate.getMinutes().toString();
    } else {
      dateString += currentDate.getMinutes().toString();
    }

    if( currentDate.getSeconds().toString().length == 1 ) {
      dateString += "0" + currentDate.getSeconds().toString();
    } else {
      dateString += currentDate.getSeconds().toString();
    }
    
    if(a) {
      dateString += "." + currentDate.getMilliseconds().toString() + "000";
    }

    return dateString;
  },

  getCurrentDate: function() {
    var currentDate = new Date();
    var date = currentDate.getDate();
    var month = currentDate.getMonth(); // => January is 0 not 1.
    var year = currentDate.getFullYear();
    var dateString = year + "-" + (month + 1) + "-" + date;
    return dateString;
  },

  getCurrentDateTime: function(a) {
	  
    var currentDate = new Date();
    var dateString = currentDate.getFullYear().toString();

    if( (currentDate.getMonth() + 1).toString().length == 1 ) {
      dateString += "-0" + (currentDate.getMonth() + 1).toString();
    } else {
      dateString += "-" + (currentDate.getMonth() + 1).toString();
    }

    if( currentDate.getDate().toString().length == 1 ) {
      dateString += "-0" + currentDate.getDate().toString();
    } else {
      dateString += "-" + currentDate.getDate().toString();
    }

    if( currentDate.getHours().toString().length == 1 ) {
      dateString += " 0" + currentDate.getHours().toString();
    } else {
      dateString += " " + currentDate.getHours().toString();
    }

    if( currentDate.getMinutes().toString().length == 1 ) {
      dateString += ":0" + currentDate.getMinutes().toString();
    } else {
      dateString += ":" + currentDate.getMinutes().toString();
    }

    if( currentDate.getSeconds().toString().length == 1 ) {
      dateString += ":0" + currentDate.getSeconds().toString();
    } else {
      dateString += ":" + currentDate.getSeconds().toString();
    }
    
    if(a) {
      dateString += "." + currentDate.getMilliseconds().toString() + "000";
    }

    return dateString;
  }
}